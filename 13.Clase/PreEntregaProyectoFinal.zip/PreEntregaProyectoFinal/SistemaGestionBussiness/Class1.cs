﻿namespace SistemaGestionBussiness
{
    public class Class1
    {

    }
}
