﻿namespace SistemaGestionData
{
    public class Class1
    {
    }
}
