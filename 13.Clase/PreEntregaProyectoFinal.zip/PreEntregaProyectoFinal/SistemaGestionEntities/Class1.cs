﻿namespace SistemaGestionEntities
{
    public class Class1
    {

    }
}
