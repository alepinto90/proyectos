﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entregable1
{
    public class Venta   //propiedades: Id, Comentario, IdUsuario
    {
        protected int Id { get; set; }
        protected string Comentario { get; set; }
        protected int IdUsuario { get; set; }

    }
}
